
public class RuntimeErrorException extends Exception{

	public RuntimeErrorException(String message)
	{
		super(message);
	}

}
